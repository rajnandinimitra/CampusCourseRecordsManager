/**
 * 
 */
/**
 * 
 */
module CampusCourseRecordsManager {
}